package catHouse.entities.toys;

public class Mouse extends BaseToy{

    public Mouse() {
        super(5,15);
    }
}
