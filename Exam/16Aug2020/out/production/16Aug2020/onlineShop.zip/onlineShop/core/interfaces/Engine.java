package onlineShop.core.interfaces;

public interface Engine extends Runnable {
}
