package spaceStation.models.bags;

import java.util.Collection;

public class Backpack implements Bag {
    Collection<String> items;

    public Backpack() {

    }

    @Override
    public Collection<String> getItems() {
        return null;
    }
}
