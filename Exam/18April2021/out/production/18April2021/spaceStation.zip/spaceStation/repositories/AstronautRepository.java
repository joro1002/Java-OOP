package spaceStation.repositories;

import spaceStation.models.astronauts.Astronaut;

import java.util.Collection;

public class AstronautRepository implements Repository<Astronaut> {
    private Collection<Astronaut> astronauts;
    @Override
    public Collection<Astronaut> getModels() {
        return null;
    }

    @Override
    public void add(Astronaut model) {

    }

    @Override
    public boolean remove(Astronaut model) {
        return false;
    }

    @Override
    public Astronaut findByName(String name) {
        return null;
    }
}
