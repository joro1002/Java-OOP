package glacialExpedition.common;

public enum Command {
    AddExplorer,
    AddState,
    RetireExplorer,
    ExploreState,
    FinalResult,
    Exit,
}
