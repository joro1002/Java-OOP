package WildFarm;

public class Vegetable extends Food {
    public Vegetable(int quantity) {
        super(quantity);
    }
}
